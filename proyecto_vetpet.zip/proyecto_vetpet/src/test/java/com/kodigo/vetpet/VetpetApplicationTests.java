package com.kodigo.vetpet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetpetApplicationTests {

	@Test
	void contextLoads() {
	}

}
