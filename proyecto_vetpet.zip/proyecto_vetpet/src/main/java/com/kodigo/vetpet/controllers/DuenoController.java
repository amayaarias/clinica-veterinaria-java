package com.kodigo.vetpet.controllers;

import com.kodigo.vetpet.models.Dueno;
import com.kodigo.vetpet.services.DuenoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/duenos")
public class DuenoController {

    @Autowired
    private DuenoService duenoService;

    // Muestra la página web con la lista de dueños
    @GetMapping
    public String listarDuenos(Model model) {
        model.addAttribute("listaDuenos", duenoService.listarTodos());
        return "duenos"; // Esto buscará un archivo llamado duenos.html
    }

    // Guarda un nuevo dueño desde el formulario web
    @PostMapping("/guardar")
    public String guardarDueno(@ModelAttribute Dueno dueno) {
        duenoService.guardar(dueno);
        return "redirect:/duenos"; // Recarga la página
    }

    // Borra un dueño
    @GetMapping("/eliminar/{id}")
    public String eliminarDueno(@PathVariable Long id) {
        duenoService.eliminar(id);
        return "redirect:/duenos";
    }
}