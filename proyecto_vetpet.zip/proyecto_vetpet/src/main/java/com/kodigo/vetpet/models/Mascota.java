package com.kodigo.vetpet.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

/**
 * Entidad que representa a los pacientes (Mascotas) de la clínica.
 */
@Entity
@Table(name = "mascota")
public class Mascota {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_mascota")
    private Long idMascota;

    @NotBlank(message = "El nombre de la mascota es obligatorio")
    @Column(nullable = false, length = 50)
    private String nombre;

    @NotBlank(message = "La especie es obligatoria")
    @Column(nullable = false, length = 50)
    private String especie;

    @Column(length = 50)
    private String raza;

    // Relación: Muchas mascotas pertenecen a un solo dueño
    @ManyToOne
    @JoinColumn(name = "id_humanoamigo", nullable = false)
    private Dueno dueno;

    public Mascota() {
    }

    // --- Getters y Setters ---

    public Long getIdMascota() {
        return idMascota;
    }

    public void setIdMascota(Long idMascota) {
        this.idMascota = idMascota;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public Dueno getDueno() {
        return dueno;
    }

    public void setDueno(Dueno dueno) {
        this.dueno = dueno;
    }
}