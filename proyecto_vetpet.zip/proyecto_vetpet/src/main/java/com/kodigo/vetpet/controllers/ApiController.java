package com.kodigo.vetpet.controllers;

import com.kodigo.vetpet.models.Dueno;
import com.kodigo.vetpet.models.Mascota;
import com.kodigo.vetpet.models.CitaMedica;
import com.kodigo.vetpet.services.DuenoService;
import com.kodigo.vetpet.services.MascotaService;
import com.kodigo.vetpet.services.CitaMedicaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controlador RESTful. Devuelve datos en formato JSON en lugar de páginas web.
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired
    private DuenoService duenoService;

    @Autowired
    private MascotaService mascotaService;

    @Autowired
    private CitaMedicaService citaService;

    @GetMapping("/duenos")
    public List<Dueno> getDuenos() {
        return duenoService.listarTodos();
    }

    @GetMapping("/mascotas")
    public List<Mascota> getMascotas() {
        return mascotaService.listarTodas();
    }

    @GetMapping("/citas")
    public List<CitaMedica> getCitas() {
        return citaService.listarTodas();
    }
}