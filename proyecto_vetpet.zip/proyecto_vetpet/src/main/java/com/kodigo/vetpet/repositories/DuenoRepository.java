package com.kodigo.vetpet.repositories;

import com.kodigo.vetpet.models.Dueno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para gestionar las operaciones de base de datos de los Dueños.
 */
@Repository
public interface DuenoRepository extends JpaRepository<Dueno, Long> {
}