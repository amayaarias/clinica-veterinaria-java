package com.kodigo.vetpet.services;

import com.kodigo.vetpet.models.Dueno;
import com.kodigo.vetpet.repositories.DuenoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Servicio que contiene la lógica de negocio para los Dueños.
 * Se encarga de las operaciones CRUD (Crear, Leer, Actualizar, Borrar).
 */
@Service
public class DuenoService {

    @Autowired
    private DuenoRepository duenoRepository;

    // Leer todos los dueños
    public List<Dueno> listarTodos() {
        return duenoRepository.findAll();
    }

    // Leer un dueño por su ID
    public Dueno obtenerPorId(Long id) {
        return duenoRepository.findById(id).orElse(null);
    }

    // Crear o Actualizar un dueño
    public Dueno guardar(Dueno dueno) {
        return duenoRepository.save(dueno);
    }

    // Borrar un dueño
    public void eliminar(Long id) {
        duenoRepository.deleteById(id);
    }
}