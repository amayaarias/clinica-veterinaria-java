package com.kodigo.vetpet.repositories;

import com.kodigo.vetpet.models.CitaMedica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para gestionar las operaciones de base de datos de las Citas Médicas.
 */
@Repository
public interface CitaMedicaRepository extends JpaRepository<CitaMedica, Long> {
}