package com.kodigo.vetpet.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

/**
 * Entidad que representa a los dueños de las mascotas en la clínica VetPet.
 */
@Entity
@Table(name = "dueno")
public class Dueno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_humanoamigo")
    private Long idHumanoAmigo;

    @NotBlank(message = "El nombre completo es obligatorio")
    @Column(name = "nombre_completo", nullable = false, length = 100)
    private String nombreCompleto;

    @Column(length = 15)
    private String telefono;

    @Email(message = "Debe ser un formato de correo válido")
    @Column(unique = true, length = 100)
    private String email;

    public Dueno() {
    }

    // --- Getters y Setters ---

    public Long getIdHumanoAmigo() {
        return idHumanoAmigo;
    }

    public void setIdHumanoAmigo(Long idHumanoAmigo) {
        this.idHumanoAmigo = idHumanoAmigo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}