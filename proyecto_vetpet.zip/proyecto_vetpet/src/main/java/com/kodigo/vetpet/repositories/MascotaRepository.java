package com.kodigo.vetpet.repositories;

import com.kodigo.vetpet.models.Mascota;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para gestionar las operaciones de base de datos de las Mascotas.
 */
@Repository
public interface MascotaRepository extends JpaRepository<Mascota, Long> {
}