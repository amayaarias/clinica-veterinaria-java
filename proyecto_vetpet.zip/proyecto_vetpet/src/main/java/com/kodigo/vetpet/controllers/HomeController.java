package com.kodigo.vetpet.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String inicio() {
        return "index"; // Esto le dice a Spring Boot que muestre el archivo index.html
    }
}