package com.kodigo.vetpet.controllers;

import com.kodigo.vetpet.models.CitaMedica;
import com.kodigo.vetpet.services.CitaMedicaService;
import com.kodigo.vetpet.services.MascotaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/citas")
public class CitaMedicaController {

    @Autowired
    private CitaMedicaService citaService;

    @Autowired
    private MascotaService mascotaService; // Para elegir a qué mascota agendar cita

    @GetMapping
    public String listarCitas(Model model) {
        model.addAttribute("listaCitas", citaService.listarTodas());
        model.addAttribute("listaMascotas", mascotaService.listarTodas());
        return "citas"; // Buscará el archivo citas.html
    }

    @PostMapping("/guardar")
    public String guardarCita(@ModelAttribute CitaMedica cita) {
        citaService.guardar(cita);
        return "redirect:/citas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCita(@PathVariable Long id) {
        citaService.eliminar(id);
        return "redirect:/citas";
    }
}