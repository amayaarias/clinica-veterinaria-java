package com.kodigo.vetpet.controllers;

import com.kodigo.vetpet.models.Mascota;
import com.kodigo.vetpet.services.MascotaService;
import com.kodigo.vetpet.services.DuenoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/mascotas")
public class MascotaController {

    @Autowired
    private MascotaService mascotaService;

    @Autowired
    private DuenoService duenoService; // Necesitamos esto para elegir al dueño de la mascota

    @GetMapping
    public String listarMascotas(Model model) {
        model.addAttribute("listaMascotas", mascotaService.listarTodas());
        model.addAttribute("listaDuenos", duenoService.listarTodos()); // Para el menú desplegable
        return "mascotas"; // Buscará el archivo mascotas.html
    }

    @PostMapping("/guardar")
    public String guardarMascota(@ModelAttribute Mascota mascota) {
        mascotaService.guardar(mascota);
        return "redirect:/mascotas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarMascota(@PathVariable Long id) {
        mascotaService.eliminar(id);
        return "redirect:/mascotas";
    }
}