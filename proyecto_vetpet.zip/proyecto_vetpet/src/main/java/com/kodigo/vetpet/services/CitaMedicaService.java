package com.kodigo.vetpet.services;

import com.kodigo.vetpet.models.CitaMedica;
import com.kodigo.vetpet.repositories.CitaMedicaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CitaMedicaService {

    @Autowired
    private CitaMedicaRepository citaRepository;

    public List<CitaMedica> listarTodas() {
        return citaRepository.findAll();
    }

    public CitaMedica obtenerPorId(Long id) {
        return citaRepository.findById(id).orElse(null);
    }

    public CitaMedica guardar(CitaMedica cita) {
        return citaRepository.save(cita);
    }

    public void eliminar(Long id) {
        citaRepository.deleteById(id);
    }
}